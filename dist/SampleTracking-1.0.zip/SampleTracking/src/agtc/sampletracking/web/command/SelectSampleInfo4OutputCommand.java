/*
 * Created on Apr 28, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package agtc.sampletracking.web.command;


/**
 * @author Hongjing
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SelectSampleInfo4OutputCommand {
	
    private boolean outExtSampleId;
    private boolean outAnotherExtSampleId;
    private boolean outOd;
    private boolean outVolumn;
    private boolean outMadeDate;
    private boolean outRefillDate;
    private boolean outNotes;
    private boolean outTransDate;
    private boolean outStatus;
    private boolean outRemoveDate;  
	private boolean outOdDate;	
	private boolean outVolumnDate;	
	private boolean outReceiveDate;	
	private boolean outSampleDupNo;
    private boolean outSampleType;  
    private boolean outSampleLoci;  
    private boolean outFname;
    private boolean outLname;
    private boolean outMname;
    private boolean outAge;
    private boolean outGender;
    private boolean outPatientNote;
    private boolean outBirthDate;
    private boolean outIsControl;
    private boolean outFamilyId;
       
    
	/**
	 * @return Returns the outAge.
	 */
	public boolean isOutAge() {
		return outAge;
	}
	/**
	 * @param outAge The outAge to set.
	 */
	public void setOutAge(boolean outAge) {
		this.outAge = outAge;
	}
	/**
	 * @return Returns the outAnotherExtSampleId.
	 */
	public boolean isOutAnotherExtSampleId() {
		return outAnotherExtSampleId;
	}
	/**
	 * @param outAnotherExtSampleId The outAnotherExtSampleId to set.
	 */
	public void setOutAnotherExtSampleId(boolean outAnotherExtSampleId) {
		this.outAnotherExtSampleId = outAnotherExtSampleId;
	}
	/**
	 * @return Returns the outBirthDate.
	 */
	public boolean isOutBirthDate() {
		return outBirthDate;
	}
	/**
	 * @param outBirthDate The outBirthDate to set.
	 */
	public void setOutBirthDate(boolean outBirthDate) {
		this.outBirthDate = outBirthDate;
	}
	/**
	 * @return Returns the outExtSampleId.
	 */
	public boolean isOutExtSampleId() {
		return outExtSampleId;
	}
	/**
	 * @param outExtSampleId The outExtSampleId to set.
	 */
	public void setOutExtSampleId(boolean outExtSampleId) {
		this.outExtSampleId = outExtSampleId;
	}
	/**
	 * @return Returns the outFamilyId.
	 */
	public boolean isOutFamilyId() {
		return outFamilyId;
	}
	/**
	 * @param outFamilyId The outFamilyId to set.
	 */
	public void setOutFamilyId(boolean outFamilyId) {
		this.outFamilyId = outFamilyId;
	}
	/**
	 * @return Returns the outFname.
	 */
	public boolean isOutFname() {
		return outFname;
	}
	/**
	 * @param outFname The outFname to set.
	 */
	public void setOutFname(boolean outFname) {
		this.outFname = outFname;
	}
	/**
	 * @return Returns the outGender.
	 */
	public boolean isOutGender() {
		return outGender;
	}
	/**
	 * @param outGender The outGender to set.
	 */
	public void setOutGender(boolean outGender) {
		this.outGender = outGender;
	}
	/**
	 * @return Returns the outIsControl.
	 */
	public boolean isOutIsControl() {
		return outIsControl;
	}
	/**
	 * @param outIsControl The outIsControl to set.
	 */
	public void setOutIsControl(boolean outIsControl) {
		this.outIsControl = outIsControl;
	}
	/**
	 * @return Returns the outLname.
	 */
	public boolean isOutLname() {
		return outLname;
	}
	/**
	 * @param outLname The outLname to set.
	 */
	public void setOutLname(boolean outLname) {
		this.outLname = outLname;
	}
	/**
	 * @return Returns the outMadeDate.
	 */
	public boolean isOutMadeDate() {
		return outMadeDate;
	}
	/**
	 * @param outMadeDate The outMadeDate to set.
	 */
	public void setOutMadeDate(boolean outMadeDate) {
		this.outMadeDate = outMadeDate;
	}
	/**
	 * @return Returns the outMname.
	 */
	public boolean isOutMname() {
		return outMname;
	}
	/**
	 * @param outMname The outMname to set.
	 */
	public void setOutMname(boolean outMname) {
		this.outMname = outMname;
	}
	
	/**
	 * @return Returns the outPatientNote.
	 */
	public boolean isOutPatientNote() {
		return outPatientNote;
	}
	/**
	 * @param outPatientNote The outPatientNote to set.
	 */
	public void setOutPatientNote(boolean outPatientNote) {
		this.outPatientNote = outPatientNote;
	}
	/**
	 * @return Returns the outNotes.
	 */
	public boolean isOutNotes() {
		return outNotes;
	}
	/**
	 * @param outNotes The outNotes to set.
	 */
	public void setOutNotes(boolean outNotes) {
		this.outNotes = outNotes;
	}
	/**
	 * @return Returns the outOd.
	 */
	public boolean isOutOd() {
		return outOd;
	}
	/**
	 * @param outOd The outOd to set.
	 */
	public void setOutOd(boolean outOd) {
		this.outOd = outOd;
	}
	/**
	 * @return Returns the outOdDate.
	 */
	public boolean isOutOdDate() {
		return outOdDate;
	}
	/**
	 * @param outOdDate The outOdDate to set.
	 */
	public void setOutOdDate(boolean outOdDate) {
		this.outOdDate = outOdDate;
	}
	/**
	 * @return Returns the outReceiveDate.
	 */
	public boolean isOutReceiveDate() {
		return outReceiveDate;
	}
	/**
	 * @param outReceiveDate The outReceiveDate to set.
	 */
	public void setOutReceiveDate(boolean outReceiveDate) {
		this.outReceiveDate = outReceiveDate;
	}
	/**
	 * @return Returns the outRefillDate.
	 */
	public boolean isOutRefillDate() {
		return outRefillDate;
	}
	/**
	 * @param outRefillDate The outRefillDate to set.
	 */
	public void setOutRefillDate(boolean outRefillDate) {
		this.outRefillDate = outRefillDate;
	}
	/**
	 * @return Returns the outRemoveDate.
	 */
	public boolean isOutRemoveDate() {
		return outRemoveDate;
	}
	/**
	 * @param outRemoveDate The outRemoveDate to set.
	 */
	public void setOutRemoveDate(boolean outRemoveDate) {
		this.outRemoveDate = outRemoveDate;
	}
	/**
	 * @return Returns the outSampleDupNo.
	 */
	public boolean isOutSampleDupNo() {
		return outSampleDupNo;
	}
	/**
	 * @param outSampleDupNo The outSampleDupNo to set.
	 */
	public void setOutSampleDupNo(boolean outSampleDupNo) {
		this.outSampleDupNo = outSampleDupNo;
	}
	/**
	 * @return Returns the outSampleLoci.
	 */
	public boolean isOutSampleLoci() {
		return outSampleLoci;
	}
	/**
	 * @param outSampleLoci The outSampleLoci to set.
	 */
	public void setOutSampleLoci(boolean outSampleLoci) {
		this.outSampleLoci = outSampleLoci;
	}
	/**
	 * @return Returns the outSampleType.
	 */
	public boolean isOutSampleType() {
		return outSampleType;
	}
	/**
	 * @param outSampleType The outSampleType to set.
	 */
	public void setOutSampleType(boolean outSampleType) {
		this.outSampleType = outSampleType;
	}
	/**
	 * @return Returns the outStatus.
	 */
	public boolean isOutStatus() {
		return outStatus;
	}
	/**
	 * @param outStatus The outStatus to set.
	 */
	public void setOutStatus(boolean outStatus) {
		this.outStatus = outStatus;
	}
	/**
	 * @return Returns the outTransDate.
	 */
	public boolean isOutTransDate() {
		return outTransDate;
	}
	/**
	 * @param outTransDate The outTransDate to set.
	 */
	public void setOutTransDate(boolean outTransDate) {
		this.outTransDate = outTransDate;
	}
	/**
	 * @return Returns the outVolumn.
	 */
	public boolean isOutVolumn() {
		return outVolumn;
	}
	/**
	 * @param outVolumn The outVolumn to set.
	 */
	public void setOutVolumn(boolean outVolumn) {
		this.outVolumn = outVolumn;
	}
	/**
	 * @return Returns the outVolumnDate.
	 */
	public boolean isOutVolumnDate() {
		return outVolumnDate;
	}
	/**
	 * @param outVolumnDate The outVolumnDate to set.
	 */
	public void setOutVolumnDate(boolean outVolumnDate) {
		this.outVolumnDate = outVolumnDate;
	}
}
