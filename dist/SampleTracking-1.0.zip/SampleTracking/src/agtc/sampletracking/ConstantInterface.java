/*
 * Created on Oct 18, 2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agtc.sampletracking;

/**
 * @author Gloria Deng
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public interface ConstantInterface {
	public static int USER_LEVEL = 1;
	public static int MANAGER_LEVEL = 2;
	public static int ADMIN_LEVEL = 3;
	public static int NO_DEF = -1;
	
	public static String NOTDEFINED = "-";
	
	public static String SAMPLE_BOX = "Sample";
	public static String REAGENT_BOX = "Reagent";
	public static String PLATE = "Plate";
	
	public static int SAMPLEID_FORMAT = 1;
	public static int PLATE_FORMAT = 2;
	public static int SAMPLEID_WELL_FORMAT = 3;
	public static int SAMPLEID_SAMPLETYPE_FORMAT = 4;
	public static int SAMPLEID_SAMPLETYPE_WELL_FORMAT = 5;
	public static int SAMPLEID_DUPNO_FORMAT = 6;
	
	public static int GENOTYPE_A = 1;
	public static int GENOTYPE_C = 2;
	public static int GENOTYPE_G = 3;
	public static int GENOTYPE_T = 4;
	public static int GENOTYPE_NO = 0;
	
	
}
