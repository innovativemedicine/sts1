function menu(size, orientation, x, y, offsetX, offsetY, bgColorOut, bgColorOver, fontFace, fontSize, 
	fontStyleOut, fontStyleOver, textColorOut, textColorOver, borderSize, borderColor, margin, showChar, 
	showOnClick, sepItems, isMainMenu, hasAnimations, animationType)
{
	this.addItem = item;
	this.addSeparator = separator;
	this.debug = debug;
}
 
function item(link, iSize, alignment, content, menuToShow)
{
	return;
}

function separator(sSize, sColor)
{
	return;
}

function debug()
{
	return;
}

var menus = new Array();